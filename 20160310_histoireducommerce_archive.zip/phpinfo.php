<!DOCTYPE HTML>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>Test PHP Info </title>
</head>

<body>
<?php
phpinfo();

?>
</body>
</html>